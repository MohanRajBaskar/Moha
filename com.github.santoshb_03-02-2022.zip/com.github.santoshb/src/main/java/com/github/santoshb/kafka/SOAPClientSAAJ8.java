package com.github.santoshb.kafka;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Properties;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.MimeHeaders;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPConnection;
import javax.xml.soap.SOAPConnectionFactory;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.commons.io.IOUtils;
import org.w3c.dom.Document;
import javax.xml.ws.soap.SOAPFaultException;
import javax.xml.soap.SOAPFault;
import javax.xml.ws.WebServiceException;
import com.github.santoshb.kafka.CrunchifyRetryNTimes.CrunchifyRetryOnExceptionStrategy;
import org.xml.sax.SAXException;
import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;

public class SOAPClientSAAJ8 {

	public static final String xmlFilePath = "C:\\Mohan\\Work\\feb\\xmlfile2.xml";

	public static void main(String args[]) throws Exception {
		InputStream input = new FileInputStream("resources/config.properties");
		Properties prop = new Properties();
		prop.load(input);
		String soapEndpointUrl = prop.getProperty("soapEndpointUrl");
		String soapAction = prop.getProperty("soapAction");
		// get the property value and print it out
		System.out.println(prop.getProperty("DEFAULT_RETRIES"));
		System.out.println(prop.getProperty("DEFAULT_WAIT_TIME_IN_MILLI"));
		System.out.println(prop.getProperty("soapEndpointUrl"));
		System.out.println(prop.getProperty("soapAction"));
		callSoapWebService(soapEndpointUrl, soapAction);
		// System.out.println("hi"+createSOAPRequest(soapAction));
	}

	private static void createSoapEnvelope(SOAPMessage soapMessage)
			throws SOAPException, ParserConfigurationException, TransformerException {
		SOAPPart soapPart = soapMessage.getSOAPPart();

		String myNamespace = "tem";
		String myNamespaceURI = "http://tempuri.org";
		SOAPEnvelope envelope = soapPart.getEnvelope();
		envelope.addNamespaceDeclaration(myNamespace, myNamespaceURI);
		SOAPBody soapBody = envelope.getBody();
		SOAPElement soapBodyElem = soapBody.addChildElement("AddInteger", myNamespace);
		SOAPElement soapBodyElem1 = soapBodyElem.addChildElement("Arg1", myNamespace);
		soapBodyElem1.addTextNode("2");
		SOAPElement soapBodyElem2 = soapBodyElem.addChildElement("Arg2", myNamespace);
		soapBodyElem2.addTextNode("3");

	}

	private static void callSoapWebService(String soapEndpointUrl, String soapAction) throws Exception {

		CrunchifyRetryOnExceptionStrategy retry = new CrunchifyRetryOnExceptionStrategy();

		try {
			SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
			SOAPConnection soapConnection = soapConnectionFactory.createConnection();
			SOAPMessage soapResponse = soapConnection.call(createSOAPRequest(soapAction), soapEndpointUrl);
			System.out.println("Response SOAP Message:");
			soapResponse.writeTo(System.out);
			System.out.println();
			soapConnection.close();
		} catch (SOAPFaultException e) {
			SOAPFault fault = e.getFault();
			String error = fault.hasDetail() ? fault.getDetail().getAttribute("Text") : fault.getFaultNode();
			System.err.println("This is catch 1 error" + error);
		} catch (WebServiceException e) {
			System.err.println("This is catch 2 error" + e.getMessage());
		} catch (Exception e) {
			System.err.println(
					"\n this Error occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
			e.printStackTrace();
			// retry.errorOccured();
			callSoapWebServiceRetry(soapEndpointUrl, soapAction);
		}
	}

	private static void callSoapWebServiceRetry(String soapEndpointUrl, String soapAction) throws Exception {
		CrunchifyRetryOnExceptionStrategy retry = new CrunchifyRetryOnExceptionStrategy();
		System.out.println("inside callSoapWebServiceRetry");

		while (retry.shouldRetry()) {
			try {

				// Create SOAP Connection
				SOAPConnectionFactory soapConnectionFactory = SOAPConnectionFactory.newInstance();
				SOAPConnection soapConnection = soapConnectionFactory.createConnection();
				String soapEndpointUrl12 = "https://www.crcind.com:443/csp/samples/SOAP.Demo.cls";
				File xmlFile;
				xmlFile = new File("C:/Mohan/Work/feb/xmlfile2.xml");
				Reader fileReader = new FileReader(xmlFile);
				BufferedReader bufReader = new BufferedReader(fileReader);
				StringBuilder sb = new StringBuilder();
				String line = bufReader.readLine();
				while (line != null) {
					sb.append(line).append("\n");
					line = bufReader.readLine();
				}
				String xml2String = sb.toString();
				System.out.println("XML to String using BufferedReader : ");
				System.out.println(xml2String);
				bufReader.close();
				InputStream is = new ByteArrayInputStream(xml2String.getBytes());
				SOAPMessage request = MessageFactory.newInstance().createMessage(null, is);
				System.out.println("hi hiXML to String using BufferedReader : ");
				System.out.println(request);
				request.writeTo(System.out);
				System.out.println();
				System.out.println("SOAP msg created1");
				SOAPMessage soapResponse = soapConnection.call(request, soapEndpointUrl);
				System.out.println("Response SOAP Message:");
				soapResponse.writeTo(System.out);
				System.out.println();

				soapConnection.close();
				break;
			} catch (Exception e) {

				System.out.println("in catch1.....");
				System.err.println(
						"\nError1 occurred while sending SOAP Request to Server!\nMake sure you have the correct endpoint URL and SOAPAction!\n");
				e.printStackTrace();
				retry.errorOccured();
			}
		}
	}

	private static SOAPMessage createSOAPRequest(String soapAction) throws Exception {
		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage soapMessage = messageFactory.createMessage();
		createSoapEnvelope(soapMessage);
		MimeHeaders headers = soapMessage.getMimeHeaders();
		headers.addHeader("SOAPAction", soapAction);
		soapMessage.saveChanges();
		System.out.println("Request SOAP Message:");
		soapMessage.writeTo(System.out);
		System.out.println("\n");
		try {
			File file;
			file = new File("C:/Mohan/Work/feb/xmlfile2.xml");
			FileOutputStream fOut = new FileOutputStream(file);
			if (!file.exists()) {
				file.createNewFile();
			}
			soapMessage.writeTo(fOut);
			fOut.flush();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}

		System.out.println();
		System.out.println("SOAP msg created");
		return soapMessage;
	}

	static class CrunchifyRetryOnExceptionStrategy {
		public static final int DEFAULT_RETRIES = 3;
		public static final long DEFAULT_WAIT_TIME_IN_MILLI = 2000;
		private int numberOfRetries;
		private int numberOfTriesLeft;
		private long timeToWait;

		public CrunchifyRetryOnExceptionStrategy() {
			this(DEFAULT_RETRIES, DEFAULT_WAIT_TIME_IN_MILLI);
		}

		public CrunchifyRetryOnExceptionStrategy(int numberOfRetries, long timeToWait) {
			this.numberOfRetries = numberOfRetries;
			numberOfTriesLeft = numberOfRetries;
			this.timeToWait = timeToWait;
		}

		/**
		 * @return true if there are tries left
		 */
		public boolean shouldRetry() {
			System.out.println("Retry count" + numberOfTriesLeft);
			return numberOfTriesLeft > 0;
		}

		public void errorOccured() throws Exception {
			if (!shouldRetry()) {
				throw new Exception("Retry Failed: Total " + numberOfRetries + " attempts made at interval "
						+ getTimeToWait() + "ms");
			}
			numberOfTriesLeft--;
			waitUntilNextTry();
		}

		public long getTimeToWait() {
			return timeToWait;
		}

		private void waitUntilNextTry() {
			try {
				Thread.sleep(getTimeToWait());
			} catch (InterruptedException ignored) {
			}
		}
	}

}
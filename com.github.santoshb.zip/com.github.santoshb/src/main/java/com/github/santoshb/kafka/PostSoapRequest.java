package com.github.santoshb.kafka;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PostSoapRequest {
	
		 public static void main(String[] args) {
		 try {
	
		 String url = "https://gd.mail.ibm.com/verse";
		 URL obj = new URL(url);
		 HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		 con.setRequestMethod("POST");
		 con.setRequestProperty("Content-Type","application/soap+xml; charset=utf-8");
		 String wfId="vcs:\\\\\\\\Projects\\\\DIB\\\\AutoFinance\\\\AF.wfd";
		 
		 String binaryData="V1BELUlELENJRixMYW5ndWFnZSxBUFBfSURfQyxMQUFfTFBQX1BST0RDQVRfQyxQSE9ORV9OTywNClhYLENJRlhYWCxFbmdsaXNoLDY3NzY4NzgsQXV0byBQZXJzb25hbCw3Njc4Njc2NzY3LA==";

		
		String xml =	"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:pnet=\"www.gmc.net/PNetTWebService/PNetTWebServices\">\r\n"
				+ "   <soapenv:Body>\r\n"
				+ "     <pnet:RunJob>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:runWorkFlowReq>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:command>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:commandName>-e</pnet:commandName>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:commandValue>dynamiccommunications</pnet:commandValue>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:command>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:responseDefinition>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:synchronous>true</pnet:synchronous>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:responseType>tBlank</pnet:responseType>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:responseDefinition>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:workFlowDefinition enableCache=\"yes\" optimization=\"tSmall\">\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:source>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:location>+wfId+</pnet:location>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:source>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:workFlowDefinition>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:dataDefinition>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:dataModuleName>DataInput1</pnet:dataModuleName>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:source>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:binaryData>\r\n"
				+binaryData+""
				+ "</pnet:binaryData>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:source>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:dataDefinition>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:command>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:commandName>-e</pnet:commandName>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "<pnet:commandValue>dynamiccommunications</pnet:commandValue>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:command>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:runWorkFlowReq>\r\n"
				+ "\r\n"
				+ " \r\n"
				+ "\r\n"
				+ "</pnet:RunJob>\r\n"
				+ "   </soapenv:Body>\r\n"
				+ "</soapenv:Envelope>";
		
		 con.setDoOutput(true);
		 DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		 wr.writeBytes(xml);
		 wr.flush();
		 wr.close();
		 String responseStatus = con.getResponseMessage();
		 System.out.println(responseStatus);
		 BufferedReader in = new BufferedReader(new InputStreamReader(
		 con.getInputStream()));
		 String inputLine;
		 StringBuffer response = new StringBuffer();
		 while ((inputLine = in.readLine()) != null) {
		 response.append(inputLine);
		 }
		 in.close();
		 System.out.println("response:" + response.toString());
		 } catch (Exception e) {
		 System.out.println(e);
		 }
		 }
		
	
}

package com.github.santoshb.kafka;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import java.util.Iterator;
import org.json.JSONException;
import org.json.JSONObject;

//import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
public class Encoding {
	
	public void getJSON(String jsonObj) throws JsonGenerationException, JsonMappingException, IOException, JSONException {
		// TODO Auto-generated method stub
		/*
		 * String jsonObj = "{\r\n" + "	\"message\": {\r\n" +
		 * "		\"title\": \"SMS\",\r\n" +
		 * "		\"Notification_Type\": \"Cooling_off_finnone\",\r\n" +
		 * "		\"TemplateID\": \"Template_id\",\r\n" +
		 * "		\"Attributes\": {\r\n" + "			\"AttributeList\": {\r\n" +
		 * "				\"ALIST\": {\r\n" +
		 * "					\"CustomerCIF\": \"CIF1234\",\r\n" +
		 * "					\"Language\": \"EN\",\r\n" +
		 * "					\"ApplicationID\": \"6510927\",\r\n" +
		 * "					\"ProductName\": \"ASPERS\",\r\n" +
		 * "					\"MobileNumber\": \"9876543210\"\r\n" +
		 * "				}\r\n" + "			}\r\n" + "		}\r\n" + "	}\r\n" +
		 * "}";
		 */
        System.out.println(jsonObj);
	
	CCMTemplate obj = new CCMTemplate();

	JSONObject jsonObject = new JSONObject(jsonObj);
	JSONObject messgageJson = jsonObject.getJSONObject("message");
	JSONObject attributesJson = (JSONObject) messgageJson.get("Attributes");
	String notificationType = (String) messgageJson.get("Notification_Type");
	String templateID = (String) messgageJson.get("TemplateID");
	//String title = (String) messgageJson.get("title");
	JSONObject attributeListJson = ((JSONObject) attributesJson).getJSONObject("AttributeList");
	JSONObject aListJson = ((JSONObject) attributeListJson).getJSONObject("ALIST");
/*	System.out.println(messgageJson);
	System.out.println("notificationType--->   " + notificationType);
	System.out.println("templateID--->  " + templateID);
	System.out.println("title---> " + title);
	System.out.println(attributesJson);
	System.out.println(attributeListJson);
	System.out.println(aListJson);
	*/
	obj.setTemplateID(templateID);
	Iterator<String> iter = aListJson.keys();
	while (iter.hasNext()) {

		try {
			String key = iter.next();
			String valued = (String) aListJson.get(key);
			//System.out.println("Alist Keys-->"+key);
			//System.out.println("Alist values-->"+valued);

			switch(key) {
	    	case "ApplicationID" :
	    			obj.setApplicationID(valued);
	    			break;
	    	}
	    	switch(key) {
	    	case "CustomerCIF" :
	    			obj.setCustomerCIF(valued);
	    			break;
	    	}
	    	switch(key) {
	    	case "EmiratesID" :
	    			obj.setEmiratesID(valued);
	    			break;
	    	}
	    	switch(key) {
	    	case "CustomerName" :
	    			obj.setCustomerName(valued);
	    			break;
	    	}
	    	switch(key) {
	    	case "CustomerNo" :
	    			obj.setCustomerNo(valued);
	    			break;
	    			}
	    	switch(key) {
	    	case "EmailID" :
	    			obj.setEmailID(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "MobileNumber" :
	    			obj.setMobileNumber(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Language" :
	    			obj.setLanguage(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "CreditLimit" :
	    			obj.setCreditLimit(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Reason" :
	    			obj.setReason(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "RequestNo" :
	    			obj.setRequestNo(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "OriginalLimit" :
	    			obj.setOriginalLimit(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "CardNo" :
	    			obj.setCardNo(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "AnticipatedDownPayment" :
	    			obj.setAnticipatedDownPayment(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ApplicableProfitRate" :
	    			obj.setApplicableProfitRate(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "BalanceOutstanding" :
	    			obj.setBalanceOutstanding(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "BalloonAmountPayableLastEMI" :
	    			obj.setBalloonAmountPayableLastEMI(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "BankingDIB" :
	    			obj.setBankingDIB(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "CompanyName" :
	    			obj.setCompanyName(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Designation" :
	    			obj.setDesignation(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "DownPayment" :
	    			obj.setDownPayment(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "DueDiligence" :
	    			obj.setDueDiligence(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "EMIDueDate" :
	    			obj.setEMIDueDate(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "EMIRepaymentPerMonth" :
	    			obj.setEMIRepaymentPerMonth(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Employer" :
	    			obj.setEmployer(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ExistingEMIAmount" :
	    			obj.setExistingEMIAmount(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "FinanceAmount" :
	    			obj.setFinanceAmount(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "FixedDepositAmount" :
	    			obj.setFixedDepositAmount(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "LastPaidDate" :
	    			obj.setLastPaidDate(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "LenghtOfService" :
	    			obj.setLenghtOfService(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "MaximumPreapprovedLimit" :
	    			obj.setMaximumPreapprovedLimit(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "MurabahaNo" :
	    			obj.setMurabahaNo(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Nationality" :
	    			obj.setNationality(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "NetOutstanding" :
	    			obj.setNetOutstanding(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "NumberInstallmentsPostponed" :
	    			obj.setNumberInstallmentsPostponed(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "NumberOfPaid" :
	    			obj.setNumberOfPaid(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Occupation" :
	    			obj.setOccupation(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "OutstandingPrincipal" :
	    			obj.setOutstandingPrincipal(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "OutstandingProfit" :
	    			obj.setOutstandingProfit(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "PaymentPerMonth" :
	    			obj.setPaymentPerMonth(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "PrincipalBookedAmount" :
	    			obj.setPrincipalBookedAmount(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ProcessingFee" :
	    			obj.setProcessingFee(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ProductName" :
	    			obj.setProductName(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Period" :
	    			obj.setPeriod(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "PurposeOfFinance" :
	    			obj.setPurposeOfFinance(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "RequestedTenor" :
	    			obj.setRequestedTenor(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "Salary" :
	    			obj.setSalary(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ServceType" :
	    			obj.setServceType(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "ServiceDefinition" :
	    			obj.setServiceDefinition(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "TotalAmountPaidBack" :
	    			obj.setTotalAmountPaidBack(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "TotalNoEMI" :
	    			obj.setTotalNoEMI(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "VehicleFromDealer" :
	    			obj.setVehicleFromDealer(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "VehicleStatus" :
	    			obj.setVehicleStatus(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "VehicleValue" :
	    			obj.setVehicleValue(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "TemplateName" :
	    			obj.setTemplateName(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "AccountNo" :
	    			obj.setAccountNo(valued);
	    			break;
	    		
	    		
	    	}
	    	switch(key) {
	    	case "PeriodDate" :
	    			obj.setPeriodDate(valued);
	    			break;
	    		
	    		
	    	}
	    	 
		} catch (JSONException e) {
			// Something went wrong!
		}
	}
	String TemplateValue = obj.getCCMValue(obj);
    System.out.println("JSON Converted Value = " +TemplateValue);
    System.out.println(TemplateValue);
    System.out.println("Encoded Value ==    "+ obj.getCCMEncodedValue(TemplateValue));
	
      
       
	}
	

	}
	

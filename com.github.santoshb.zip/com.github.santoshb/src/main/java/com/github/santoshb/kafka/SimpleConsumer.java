package com.github.santoshb.kafka;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class SimpleConsumer {
	
	public static void main(String[] args) throws JsonGenerationException, JsonMappingException, IOException {
		// TODO Auto-generated method stub
		
		String bootstrapServer = "localhost:9092";
		String groupId = "My-Third-Application";
		String topics = "first_topic";
	    String jsonObj = "";
		Encoding e=new Encoding();
		
		Properties properties = new Properties();
		properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
		properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName() );
		properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, groupId);
		properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");

		
		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(properties);
		
		
		consumer.subscribe(Arrays.asList(topics));
		
		System.out.println("Json......."+topics);
	
			  
			 
			 while(true) {
				 ConsumerRecords<String, String>  records =  consumer.poll(Duration.ofMillis(100));
			  for (ConsumerRecord<String, String> record : records) {
				  	String key = record.key();
				  	jsonObj = record.value();
				  	System.out.println(".........value"+jsonObj);
				  	
				  }
			  e.getJSON(jsonObj);
			  System.out.println("hgghghg"+jsonObj);
	}
			  
			  
		
		

	}

}

package com.github.santoshb.kafka;

import java.util.Properties;

import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SimpleProducer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("Hello world");
		//String bootstrapServer = "127.0.0.1:9092";
		String bootstrapServer = "localhost:9092";
		Properties properties = new Properties();
		properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServer);
		properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName());
		properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,StringSerializer.class.getName() );

		
		
		
		for(int i=0;i<10;i++) {
			
			KafkaProducer<String, String> producer = new KafkaProducer<String, String>(properties);
		    
			Callback callBack = new Callback() {
				Logger logger =  LoggerFactory.getLogger(SimpleProducer.class);
				
				public void onCompletion(RecordMetadata metadata, Exception exception) {
					// TODO Auto-generated method stub
					if (exception == null ) {
						
						logger.info("MetaData = \n Partition ="+ metadata.partition());
						logger.info("\n offset ="+ metadata.partition());
						logger.info("\n offset ="+ metadata.offset());
						
					}else {
						logger.error("Exception = " +exception);
					}
				}
			};
			String data = new String("Hello world 122312 = "+i);
			
			System.out.println("printing data"+data);
			
			ProducerRecord<String, String> record = new ProducerRecord<String, String>("first_topic",data);
			
			producer.send(record,callBack);
			
			producer.flush();
			producer.close();
			
		}
		
		
	
	
	}

}

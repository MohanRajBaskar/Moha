package com.github.santoshb.kafka;
import java.util.Base64;
public class CCMTemplate {
    private String TemplateID; 
    private String CustomerCIF; 
    private String EmiratesID; 
    private String CustomerName; 
    private String CustomerNo; 
    private String EmailID; 
    private String MobileNumber; 
    private String Language; 
    private String CreditLimit; 
    private String Reason; 
    private String RequestNo; 
    private String ApplicationID; 
    private String OriginalLimit; 
    private String CardNo; 
    private String AnticipatedDownPayment; 
    private String ApplicableProfitRate; 
    private String BalanceOutstanding; 
    private String BalloonAmountPayableLastEMI; 
    private String BankingDIB; 
    private String CompanyName; 
    private String Designation; 
    private String DownPayment; 
    private String DueDiligence; 
    private String EMIDueDate; 
    private String EMIRepaymentPerMonth; 
    private String Employer; 
    private String ExistingEMIAmount; 
    private String FinanceAmount; 
    private String FixedDepositAmount; 
    private String LastPaidDate; 
    private String LenghtOfService; 
    private String MaximumPreapprovedLimit; 
    private String MurabahaNo; 
    private String Nationality; 
    private String NetOutstanding; 
    private String NumberInstallmentsPostponed; 
    private String NumberOfPaid; 
    private String Occupation; 
    private String OutstandingPrincipal; 
    private String OutstandingProfit; 
    private String PaymentPerMonth; 
    private String PrincipalBookedAmount; 
    private String ProcessingFee; 
    private String ProductName; 
    private String Period; 
    private String PurposeOfFinance; 
    private String RequestedTenor; 
    private String Salary; 
    private String ServceType; 
    private String ServiceDefinition; 
    private String TotalAmountPaidBack; 
    private String TotalNoEMI; 
    private String VehicleFromDealer; 
    private String VehicleStatus; 
    private String VehicleValue; 
    private String TemplateName; 
    private String AccountNo; 
    private String PeriodDate;
    private String RL_AutoRenewal_Fixed; 
    private static String HEADER_VALUE = "TemplateID,CustomerCIF,EmiratesID,CustomerName,CustomerNo,EmailID,MobileNumber,Language,CreditLimit,Reason,RequestNo,ApplicationID,OriginalLimit,CardNo,AnticipatedDownPayment,ApplicableProfitRate,BalanceOutstanding,BalloonAmountPayableLastEMI,BankingDIB,CompanyName,Designation,DownPayment,DueDiligence,EMIDueDate,EMIRepaymentPerMonth,Employer,ExistingEMIAmount,FinanceAmount,FixedDepositAmount,LastPaidDate,LenghtOfService,MaximumPreapprovedLimit,MurabahaNo,Nationality,NetOutstanding,NumberInstallmentsPostponed,NumberOfPaid,Occupation,OutstandingPrincipal,OutstandingProfit,PaymentPerMonth,PrincipalBookedAmount,ProcessingFee,ProductName,Period,PurposeOfFinance,RequestedTenor,Salary,ServceType,ServiceDefinition,TotalAmountPaidBack,TotalNoEMI,VehicleFromDealer,VehicleStatus,VehicleValue,TemplateName,AccountNo,PeriodDate,RL_AutoRenewal_Fixed";
    public CCMTemplate() {
        
    }
    public String getTemplateID() {
        return TemplateID;
    }
    public void setTemplateID(String templateID) {
        TemplateID = templateID;
    }
    public String getBankingDIB() {
        return BankingDIB;
    }
    public void setBankingDIB(String bankingDIB) {
        BankingDIB = bankingDIB;
    }
    public String getCustomerCIF() {
        return CustomerCIF;
    }
    public void setCustomerCIF(String customerCIF) {
        CustomerCIF = customerCIF;
    }
    public String getEmiratesID() {
        return EmiratesID;
    }
    public void setEmiratesID(String emiratesID) {
        EmiratesID = emiratesID;
    }
    public String getCustomerName() {
        return CustomerName;
    }
    public void setCustomerName(String customerName) {
        CustomerName = customerName;
    }
    public String getCustomerNo() {
        return CustomerNo;
    }
    public void setCustomerNo(String customerNo) {
        CustomerNo = customerNo;
    }
    public String getEmailID() {
        return EmailID;
    }
    public void setEmailID(String emailID) {
        EmailID = emailID;
    }
    public String getMobileNumber() {
        return MobileNumber;
    }
    public void setMobileNumber(String mobileNumber) {
        MobileNumber = mobileNumber;
    }
    public String getLanguage() {
        return Language;
    }
    public void setLanguage(String language) {
        Language = language;
    }
    public String getCreditLimit() {
        return CreditLimit;
    }
    public void setCreditLimit(String creditLimit) {
        CreditLimit = creditLimit;
    }
    public String getReason() {
        return Reason;
    }
    public void setReason(String reason) {
        Reason = reason;
    }
    public String getRequestNo() {
        return RequestNo;
    }
    public void setRequestNo(String requestNo) {
        RequestNo = requestNo;
    }
    public String getApplicationID() {
        return ApplicationID;
    }
    public void setApplicationID(String applicationID) {
        ApplicationID = applicationID;
    }
    public String getOriginalLimit() {
        return OriginalLimit;
    }
    public void setOriginalLimit(String originalLimit) {
        OriginalLimit = originalLimit;
    }
    public String getCardNo() {
        return CardNo;
    }
    public void setCardNo(String cardNo) {
        CardNo = cardNo;
    }
    public String getAnticipatedDownPayment() {
        return AnticipatedDownPayment;
    }
    public void setAnticipatedDownPayment(String anticipatedDownPayment) {
        AnticipatedDownPayment = anticipatedDownPayment;
    }
    public String getApplicableProfitRate() {
        return ApplicableProfitRate;
    }
    public void setApplicableProfitRate(String applicableProfitRate) {
        ApplicableProfitRate = applicableProfitRate;
    }
    public String getBalanceOutstanding() {
        return BalanceOutstanding;
    }
    public void setBalanceOutstanding(String balanceOutstanding) {
        BalanceOutstanding = balanceOutstanding;
    }
    public String getBalloonAmountPayableLastEMI() {
        return BalloonAmountPayableLastEMI;
    }
    public void setBalloonAmountPayableLastEMI(String balloonAmountPayableLastEMI) {
        BalloonAmountPayableLastEMI = balloonAmountPayableLastEMI;
    }
    public String getCompanyName() {
        return CompanyName;
    }
    public void setCompanyName(String companyName) {
        CompanyName = companyName;
    }
    public String getDesignation() {
        return Designation;
    }
    public void setDesignation(String designation) {
        Designation = designation;
    }
    public String getDownPayment() {
        return DownPayment;
    }
    public void setDownPayment(String downPayment) {
        DownPayment = downPayment;
    }
    public String getDueDiligence() {
        return DueDiligence;
    }
    public void setDueDiligence(String dueDiligence) {
        DueDiligence = dueDiligence;
    }
    public String getEMIDueDate() {
        return EMIDueDate;
    }
    public void setEMIDueDate(String eMIDueDate) {
        EMIDueDate = eMIDueDate;
    }
    public String getEMIRepaymentPerMonth() {
        return EMIRepaymentPerMonth;
    }
    public void setEMIRepaymentPerMonth(String eMIRepaymentPerMonth) {
        EMIRepaymentPerMonth = eMIRepaymentPerMonth;
    }
    public String getEmployer() {
        return Employer;
    }
    public void setEmployer(String employer) {
        Employer = employer;
    }
    public String getExistingEMIAmount() {
        return ExistingEMIAmount;
    }
    public void setExistingEMIAmount(String existingEMIAmount) {
        ExistingEMIAmount = existingEMIAmount;
    }
    public String getFinanceAmount() {
        return FinanceAmount;
    }
    public void setFinanceAmount(String financeAmount) {
        FinanceAmount = financeAmount;
    }
    public String getFixedDepositAmount() {
        return FixedDepositAmount;
    }
    public void setFixedDepositAmount(String fixedDepositAmount) {
        FixedDepositAmount = fixedDepositAmount;
    }
    public String getLastPaidDate() {
        return LastPaidDate;
    }
    public void setLastPaidDate(String lastPaidDate) {
        LastPaidDate = lastPaidDate;
    }
    public String getLenghtOfService() {
        return LenghtOfService;
    }
    public void setLenghtOfService(String lenghtOfService) {
        LenghtOfService = lenghtOfService;
    }
    public String getMaximumPreapprovedLimit() {
        return MaximumPreapprovedLimit;
    }
    public void setMaximumPreapprovedLimit(String maximumPreapprovedLimit) {
        MaximumPreapprovedLimit = maximumPreapprovedLimit;
    }
    public String getMurabahaNo() {
        return MurabahaNo;
    }
    public void setMurabahaNo(String murabahaNo) {
        MurabahaNo = murabahaNo;
    }
    public String getNationality() {
        return Nationality;
    }
    public void setNationality(String nationality) {
        Nationality = nationality;
    }
    public String getNetOutstanding() {
        return NetOutstanding;
    }
    public void setNetOutstanding(String netOutstanding) {
        NetOutstanding = netOutstanding;
    }
    public String getNumberInstallmentsPostponed() {
        return NumberInstallmentsPostponed;
    }
    public void setNumberInstallmentsPostponed(String numberInstallmentsPostponed) {
        NumberInstallmentsPostponed = numberInstallmentsPostponed;
    }
    public String getNumberOfPaid() {
        return NumberOfPaid;
    }
    public void setNumberOfPaid(String numberOfPaid) {
        NumberOfPaid = numberOfPaid;
    }
    public String getOccupation() {
        return Occupation;
    }
    public void setOccupation(String occupation) {
        Occupation = occupation;
    }
    public String getOutstandingPrincipal() {
        return OutstandingPrincipal;
    }
    public void setOutstandingPrincipal(String outstandingPrincipal) {
        OutstandingPrincipal = outstandingPrincipal;
    }
    public String getOutstandingProfit() {
        return OutstandingProfit;
    }
    public void setOutstandingProfit(String outstandingProfit) {
        OutstandingProfit = outstandingProfit;
    }
    public String getPaymentPerMonth() {
        return PaymentPerMonth;
    }
    public void setPaymentPerMonth(String paymentPerMonth) {
        PaymentPerMonth = paymentPerMonth;
    }
    public String getPrincipalBookedAmount() {
        return PrincipalBookedAmount;
    }
    public void setPrincipalBookedAmount(String principalBookedAmount) {
        PrincipalBookedAmount = principalBookedAmount;
    }
    public String getProcessingFee() {
        return ProcessingFee;
    }
    public void setProcessingFee(String processingFee) {
        ProcessingFee = processingFee;
    }
    public String getProductName() {
        return ProductName;
    }
    public void setProductName(String productName) {
        ProductName = productName;
    }
    public String getPeriod() {
        return Period;
    }
    public void setPeriod(String period) {
        Period = period;
    }
    public String getPurposeOfFinance() {
        return PurposeOfFinance;
    }
    public void setPurposeOfFinance(String purposeOfFinance) {
        PurposeOfFinance = purposeOfFinance;
    }
    public String getRequestedTenor() {
        return RequestedTenor;
    }
    public void setRequestedTenor(String requestedTenor) {
        RequestedTenor = requestedTenor;
    }
    public String getSalary() {
        return Salary;
    }
    public void setSalary(String salary) {
        Salary = salary;
    }
    public String getServceType() {
        return ServceType;
    }
    public void setServceType(String servceType) {
        ServceType = servceType;
    }
    public String getServiceDefinition() {
        return ServiceDefinition;
    }
    public void setServiceDefinition(String serviceDefinition) {
        ServiceDefinition = serviceDefinition;
    }
    public String getTotalAmountPaidBack() {
        return TotalAmountPaidBack;
    }
    public void setTotalAmountPaidBack(String totalAmountPaidBack) {
        TotalAmountPaidBack = totalAmountPaidBack;
    }
    public String getTotalNoEMI() {
        return TotalNoEMI;
    }
    public void setTotalNoEMI(String totalNoEMI) {
        TotalNoEMI = totalNoEMI;
    }
    public String getVehicleFromDealer() {
        return VehicleFromDealer;
    }
    public void setVehicleFromDealer(String vehicleFromDealer) {
        VehicleFromDealer = vehicleFromDealer;
    }
    public String getVehicleStatus() {
        return VehicleStatus;
    }
    public void setVehicleStatus(String vehicleStatus) {
        VehicleStatus = vehicleStatus;
    }
    public String getVehicleValue() {
        return VehicleValue;
    }
    public void setVehicleValue(String vehicleValue) {
        VehicleValue = vehicleValue;
    }
    public String getTemplateName() {
        return TemplateName;
    }
    public void setTemplateName(String templateName) {
        TemplateName = templateName;
    }
    public String getAccountNo() {
        return AccountNo;
    }
    public void setAccountNo(String accountNo) {
        AccountNo = accountNo;
    }
    public String getPeriodDate() {
        return PeriodDate;
    }
    public void setPeriodDate(String periodDate) {
        PeriodDate = periodDate;
    }
    public String getRL_AutoRenewal_Fixed() {
        return RL_AutoRenewal_Fixed;
    }
    public void setRL_AutoRenewal_Fixed(String rL_AutoRenewal_Fixed) {
        RL_AutoRenewal_Fixed = rL_AutoRenewal_Fixed;
    }
    
    private String valueOf(String value)
    {
        if (value == null) {
            return value=",";
        }
        return value+=",";
    }
    
    private String lastValueOf(String value)
    {
        if (value == null) {
            return value=",";
        }
        return value+=",";
    }
    
    public String getCCMValue(CCMTemplate template) {
        
        String value = valueOf(getTemplateID())+valueOf(getCustomerCIF())+valueOf(getEmiratesID())+valueOf(getCustomerName())+valueOf(getCustomerNo())+valueOf(getEmailID())+valueOf(getMobileNumber())+valueOf(getLanguage())+valueOf(getCreditLimit())+valueOf(getReason())+valueOf(getRequestNo())+valueOf(getApplicationID())+valueOf(getOriginalLimit())+valueOf(getCardNo())+valueOf(getAnticipatedDownPayment())+valueOf(getApplicableProfitRate())+valueOf(getBalanceOutstanding())+valueOf(getBalloonAmountPayableLastEMI())+valueOf(getBankingDIB())+valueOf(getCompanyName())+valueOf(getDesignation())+valueOf(getDownPayment())+valueOf(getDueDiligence())+valueOf(getEMIDueDate())+valueOf(getEMIRepaymentPerMonth())+valueOf(getEmployer())+valueOf(getExistingEMIAmount())+valueOf(getFinanceAmount())+valueOf(getFixedDepositAmount())+valueOf(getLastPaidDate())+valueOf(getLenghtOfService())+valueOf(getMaximumPreapprovedLimit())+valueOf(getMurabahaNo())+valueOf(getNationality())+valueOf(getNetOutstanding())+valueOf(getNumberInstallmentsPostponed())+valueOf(getNumberOfPaid())+valueOf(getOccupation())+valueOf(getOutstandingPrincipal())+valueOf(getOutstandingProfit())+valueOf(getPaymentPerMonth())+valueOf(getPrincipalBookedAmount())+valueOf(getProcessingFee())+valueOf(getProductName())+valueOf(getPeriod())+valueOf(getPurposeOfFinance())+valueOf(getRequestedTenor())+valueOf(getSalary())+valueOf(getServceType())+valueOf(getServiceDefinition())+valueOf(getTotalAmountPaidBack())+valueOf(getTotalNoEMI())+valueOf(getVehicleFromDealer())+valueOf(getVehicleStatus())+valueOf(getVehicleValue())+valueOf(getTemplateName())+valueOf(getAccountNo())+valueOf(getPeriodDate());
         value += lastValueOf(getRL_AutoRenewal_Fixed());
         return HEADER_VALUE +"\n"+value;
    }
    
    // Cust001,123456789,Pınar,CN001,pinar.gun@dtechsfot.com,05041544545,EN,,,,AppID000253,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,Fixed Deposit,May,,,,,,,,,,1,,,15/05/2022
    public static void main(String[] args) {
        /*CCMTemplate obj = new CCMTemplate();
        obj.setCustomerCIF("12345678");
    //  obj.setApplicationID("AP198047387483");
        obj.setTemplateID("Notification->12345");
        
        String attributeName = "ApplicationID";
        String attributeValue = "TestApplciation";
        
        switch(attributeName) {
        case "ApplicationID" :
                obj.setApplicationID(attributeValue);
                break;
           
            
        }
      */
        
    }
    
	public String getCCMEncodedValue(String source) {
        //source += HEADER_VALUE+",";
        return Base64.getEncoder().encodeToString(source.getBytes());
    }
    
    /**
     * 
     * @param source
     * @return
     */
    
    
}
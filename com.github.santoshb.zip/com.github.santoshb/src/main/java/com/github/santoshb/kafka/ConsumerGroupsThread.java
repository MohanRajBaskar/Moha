package com.github.santoshb.kafka;

import java.io.IOException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Collection;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;

public class ConsumerGroupsThread {

	static String json;
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		 
        new  ConsumerGroupsThread();
        System.out.println("ConsumerGroupsThread class");
        
        
	}
	void getjson(String json) throws JsonGenerationException, JsonMappingException, IOException {
		
		Encoding encode =new Encoding();
		encode.getJSON(json);
		
	}
	
	public ConsumerGroupsThread(){
		
		String bootstrapServer = "localhost:9092";
		String groupId = "My-Fourth-Application";
		String topics = "first_topic";
		CountDownLatch latch = new CountDownLatch(1);
		ConsumerGroupThreadRunnabble runnableInstance = new ConsumerGroupThreadRunnabble(groupId,bootstrapServer,latch,topics);
		
		Thread myThread = new Thread(runnableInstance);
		
		myThread.start();
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			
			System.out.println("Closing connection .....");
			
			((ConsumerGroupThreadRunnabble)runnableInstance).shutDown();
			
			try {

				latch.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}

		));
			
		try {
			latch.await();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
		//	e.printStackTrace();
		}
		
	}
	
	public class ConsumerGroupThreadRunnabble implements Runnable{
		
		private CountDownLatch latch;
		private KafkaConsumer<String, String> consumer ;
		private String topics;
		private String bootStrarpServer;
		private String groupId;
		
		
		
		private ConsumerGroupThreadRunnabble(String groupId, String bootStrapServer, CountDownLatch latch, String topics){
			this.latch = latch;
			this.topics = topics;
			this.bootStrarpServer = bootStrapServer;
			this.groupId = groupId;
		}
		public void run() {
			// TODO Auto-generated method stub
			Properties properties = new Properties();
			properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootStrarpServer);
			properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());
			properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName() );
			properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, groupId);
			properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
			Encoding encode =new Encoding();
			consumer = new KafkaConsumer<String, String>(properties);
			consumer.subscribe(Arrays.asList(topics));
		
			try {
				while(true) {
					  ConsumerRecords<String, String>  records =  consumer.poll(Duration.ofMillis(100));
					 
					  for (ConsumerRecord<String, String> record : records) {
						  
						  	String key = record.key();
						  	json = record.value();
						  	System.out.println(" key ="+key  );
						  	System.out.println(" Value ="+json  );
						  	try {
						  		System.out.println("call getjson metthos");
								encode.getJSON(json);
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						  }
				}
				
			} catch (WakeupException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
				System.out.println("Sturtting down ...");
			}finally {
				consumer.close();
				
		}
		}
		public void shutDown() {
			consumer.wakeup();
			// Special method to interrupt the poll method.
			
		}

	}
	

}




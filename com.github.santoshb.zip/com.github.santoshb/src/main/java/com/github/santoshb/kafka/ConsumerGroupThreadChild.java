package com.github.santoshb.kafka;

public class ConsumerGroupThreadChild implements Runnable{

	public void run() {
		// TODO Auto-generated method stub
		
	}
	
	public void shutDown() {
		
	}

}
